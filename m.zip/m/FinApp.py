from flask import Flask, render_template, request, redirect, url_for
from flask_mysqldb import MySQL
import yaml
import webbrowser

app = Flask(__name__)

# Configure db
db = yaml.load(open(r'C:\Users\Saabia\Desktop\m\dbReg.yaml'))
app.config['MYSQL_HOST'] = db['mysql_host']
app.config['MYSQL_USER'] = db['mysql_user']
app.config['MYSQL_PASSWORD'] = db['mysql_password']
app.config['MYSQL_DB'] = db['mysql_db']
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'


mysql = MySQL(app)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Fetch form data
        userDetails = request.form
        fname = userDetails['fn']
        org = userDetails['cm']
        bname = userDetails['bm']
        sem = userDetails['bms']
        mobNo = userDetails['mn']
        Ano = userDetails['amn']
        email = userDetails['email']
        fatname = userDetails['ftn']
        fcon = userDetails['c']
        address = userDetails['ad']
        status = userDetails['status']
        module = userDetails['modu']
        Remark = userDetails['re']
        cpro = userDetails['cpro']
        date = userDetails['date']
        time = userDetails['time']
        duration = userDetails['duration']
        fee = userDetails['Totalfee']
        rem = userDetails['rem']
        cur = mysql.connection.cursor()
        print('hello', cur)
        cur.execute("INSERT INTO Rdta(fname, org, bname, sem, mobNo, Ano, email, fatname, fcon, address, status, module, Remark, cpro, date, time, duration, fee, rem) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",(fname, org, bname, sem, mobNo, Ano, email, fatname, fcon, address, status, module, Remark, cpro, date, time, duration, fee, rem))
        mysql.connection.commit()
        cur.close()
        val = 'Registration Sucess!!'
        return render_template('m.html', value=val)
    return render_template('m.html')

# @app.route('/usersReg')
# def users():
#     cur = mysql.connection.cursor()
#     table1 = "SELECT * FROM Rdta"
#     print('table1', table1)
#     resultValue = cur.execute(table1)
#     print('resultValue', resultValue)
#     if resultValue > 0:
#         userDetails = cur.fetchall()
#         print('userDetails', userDetails)
#         return render_template('usersReg.html',userDetails=userDetails)

@app.route('/usersReg')
def users():
    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT * FROM Rdta")
    userDetails = cur.fetchall()
    print('userDetails', userDetails)
    Val = "SELECT DATE_FORMAT(date, '%M %e %Y') FROM Rdta"
    cur.execute(Val)
    Val = cur.fetchall()
    print('value',Val)

    if resultValue > 0:

        return render_template('usersReg.html',userDetails=userDetails, value=Val)

@app.route('/in', methods=['GET', 'POST'])
def index1():
    if request.method == 'POST':
        # Fetch form data
        userDetails = request.form
        IDs = userDetails['id']
        DATES = userDetails['date']
        amount = userDetails['amount']
        mode = userDetails['mode']
        des = userDetails['des']
        # preparing a cursor object
        cursorObject = mysql.connection.cursor()
        query = "SELECT * FROM Rdta "
        # cursorObject.execute(query)
        print("QUERY :", cursorObject.execute(query))
        cursorObject.execute("INSERT INTO Rtdt(IDs, DATES, amount, mode, des) VALUES(%s, %s, %s, %s, %s)", (IDs, DATES, amount, mode, des))
        # selecting query
        query1 = "SELECT * FROM Rdta WHERE Rdta.Stud_ID =" +str(IDs)
        cursorObject.execute(query1)
        print("QUERY1 :", query1)
        myresult = cursorObject.fetchall()
        print('MYRESULT', myresult)
        mysql.connection.commit()
        print(myresult)
        tabdic = dict()
        tabdic['IDs'] = IDs
        tabdic['DATES'] = DATES
        tabdic['mode'] = mode
        tabdic['amount'] = amount
        print(tabdic)
        queryser = "SELECT serial_no FROM Rtdt ORDER BY serial_no DESC LIMIT 1;"

        cursorObject.execute(queryser)
        sera = cursorObject.fetchall()
        print("this is serial numer",sera)
        print("this is dict")
        print("this is my result : ",myresult)
        #myresult.update(tabdic)
        print("IS THIS APPENDED")

        for kt in myresult:
            print(kt["rem"])
            y=kt["rem"]
            print("rem", y)

        k = tabdic['amount']
        print('Amount', k)
        y = int(y)
        k = int(k)
        z = y-k
        print('Due',z)
        updata = "update Rdta SET rem='"+str(z)+"'WHERE Stud_ID="+str(IDs)+";"
        cursorObject.execute(updata)
        print('UPDATE',updata)
        mysql.connection.commit()

        return render_template('indexForm.html', userDetails=myresult, k = tabdic, jina=sera, remaining=z)
    return render_template('indexRect.html')

@app.route('/usersRect')
def users1():
    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT * FROM Rtdt")
    userDetails = cur.fetchall()
    print('userDetails', userDetails)
    Val = "SELECT DATE_FORMAT(DATES, '%M %e %Y') FROM Rtdt"
    cur.execute(Val)
    Val = cur.fetchall()
    print('value',Val)

    if resultValue > 0:

        return render_template('usersRect.html',userDetails=userDetails, value=Val)

@app.route('/usersNameSort')
def users2():
    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT Rdta.Stud_ID, Rdta.fname, Rdta.org, Rdta.bname, Rdta.sem, Rdta.mobNo, Rdta.email, Rdta.fatname, Rdta.fcon, Rdta.module, Rdta.cpro, Rdta.date, Rdta.duration, Rdta.fee, Rdta.rem FROM Rdta ORDER BY date ASC")
    print('Sort list by Date:', resultValue)

    if resultValue > 0:
        userDetails = cur.fetchall()
        return render_template('usersNameSort.html',userDetails=userDetails)

@app.route('/usersDuefee')
def users3():
    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT Rdta.Stud_ID, Rdta.fname, Rdta.mobNo, Rdta.module, Rdta.date, Rdta.fee, Rdta.rem FROM Rdta WHERE rem>0")
    print('Remaining fee:', resultValue)

    if resultValue > 0:
        userDetails = cur.fetchall()
        return render_template('usersDuefee.html',userDetails=userDetails)

@app.route('/usersJoinedModule')
def users4():
    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT module, COUNT(*) FROM Rdta GROUP BY module")
    print('No. of courses joined:', resultValue)

    if resultValue > 0:
        userDetails = cur.fetchall()
        print('courses joined:', userDetails)
        return render_template('usersJoinedModule.html',userDetails=userDetails)

@app.route('/usersPerMonSum')
def users5():
    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT MONTHNAME(date), YEAR(date), SUM(fee), SUM(rem) FROM Rdta GROUP BY YEAR(date), MONTH(date)")
    print('Per Month Total:', resultValue)

    if resultValue > 0:
        userDetails = cur.fetchall()
        print('courses total per month:', userDetails)
        return render_template('usersPerMonSum.html',userDetails=userDetails)

@app.route('/usersTrainingPro')
def users6():
    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT cpro, COUNT(*) FROM Rdta GROUP BY cpro")
    print('Per Month Total:', resultValue)

    if resultValue > 0:
        userDetails = cur.fetchall()
        print('Type of Training Programm:', userDetails)
        return render_template('usersTrainingPro.html',userDetails=userDetails)

# @app.route('/usersIDName')
# def users7():
#     cur = mysql.connection.cursor()
#     resultValue = cur.execute("SELECT * FROM Rtdt")
#     userDetails = cur.fetchall()
#     print('userDetails', userDetails)
#     Val = "SELECT fname  FROM Rdta, Rtdt WHERE Rdta.Stud_ID=Rtdt.IDs"
#     cur.execute(Val)
#     Val = cur.fetchall()
#     print('value',Val)
#
#     if resultValue > 0:
#
#         return render_template('usersRect.html',userDetails=userDetails, value=Val, values=Vals)

# @app.route('/usersIDName')
# def users7():
#     cur = mysql.connection.cursor()
#     resultValue = cur.execute("SELECT * FROM Rtdt")
#     userDetails = cur.fetchall()
#     print('userDetails', userDetails)
#     ValDate = "SELECT DATE_FORMAT(DATES, '%M %e %Y') FROM Rtdt"
#     cur.execute(ValDate)
#     Val = cur.fetchall()
#     print('valueDATE-',ValDate)
#     ValsID = "SELECT fname  FROM Rdta, Rtdt WHERE Rdta.Stud_ID=Rtdt.IDs"
#     cur.execute(ValsID)
#     ValsID = cur.fetchall()
#     print('value-ID',ValsID)
#
#     if resultValue > 0:
#         return render_template('usersRect.html',userDetails=userDetails, value=Val, values=Vals)



@app.route('/Entry', methods=['GET', 'POST'])
def index3():
    return render_template('tra.html')


if __name__ == '__main__':
    app.run(debug=True, port=5500)
